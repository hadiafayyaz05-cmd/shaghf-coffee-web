/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Preloader } from './components/Preloader';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { OfferBanner } from './components/OfferBanner';
import { GallerySection } from './components/GallerySection';
import { StorySection } from './components/StorySection';
import { ReviewsSection } from './components/ReviewsSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className="min-h-screen bg-[#1E130C] text-[#F5EBDD] font-sans antialiased selection:bg-[#C9A24B]/30 selection:text-[#F5EBDD]">
      {/* 1. Page Load Preloader */}
      <Preloader onComplete={() => setLoaded(true)} />

      {/* 2. Top Navbar */}
      <Navbar />

      <main id="main-content">
        {/* 3. Hero Section (full screen) */}
        <Hero />

        {/* 4. Menu Intro & Filter Tabs Grid */}
        <MenuSection />

        {/* 5. Special Offer Banner */}
        <OfferBanner />

        {/* 6. Photo Gallery with Lightbox */}
        <GallerySection />

        {/* 7. Our Story with Parallax & Animated Counter Stats */}
        <StorySection />

        {/* 8. Customer Reviews Auto-Sliding Carousel */}
        <ReviewsSection />

        {/* 9. Location, Opening Hours & Embedded Google Map */}
        <LocationSection />
      </main>

      {/* 10. Footer with Animated Gold Border */}
      <Footer />

      {/* 11. Floating WhatsApp Button with Gentle Pulse */}
      <FloatingWhatsApp />
    </div>
  );
}
