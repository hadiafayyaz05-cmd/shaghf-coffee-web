import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, MessageSquare, MapPin } from 'lucide-react';
import { BUSINESS_INFO, getWhatsAppOrderUrl } from '../data/coffeeData';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile drawer on escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileMenuOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Menu', href: '#menu' },
    { label: 'Offers', href: '#offer' },
    { label: 'Our Story', href: '#story' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Location', href: '#location' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#1E130C]/95 backdrop-blur-md shadow-lg shadow-black/40 border-b border-[#C9A24B]/20 py-3.5'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-8">
            {/* Zone 1: Brand Wordmark */}
            <a
              href="#home"
              className="group flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B]"
              aria-label="Shaghf Coffee Quetta - Back to top"
            >
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-serif text-2xl sm:text-3xl font-bold tracking-wider text-[#F5EBDD] group-hover:text-[#C9A24B] transition-colors">
                    Shaghf
                  </span>
                  <span className="text-[#C9A24B] text-lg font-serif">شغف</span>
                </div>
                <span className="text-[10px] uppercase tracking-[0.25em] text-[#C9A24B] -mt-1 font-semibold">
                  DHA Quetta
                </span>
              </div>
            </a>

            {/* Zone 2: Navigation Links (Desktop) */}
            <nav
              className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#F5EBDD]/90"
              aria-label="Main Navigation"
            >
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="whitespace-nowrap transition-colors hover:text-[#C9A24B] relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#C9A24B] hover:after:w-full after:transition-all after:duration-300"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* Zone 3: Primary Action & Mobile Hamburger */}
            <div className="flex items-center gap-3 shrink-0">
              <a
                href={getWhatsAppOrderUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold tracking-wide text-[#1E130C] bg-[#C9A24B] hover:bg-[#d9b259] rounded-full transition-all duration-200 shadow-md hover:shadow-lg hover:shadow-[#C9A24B]/20 active:scale-95 whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4 fill-[#1E130C]" />
                <span>Order on WhatsApp</span>
              </a>

              {/* Mobile Hamburger Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 text-[#F5EBDD] hover:text-[#C9A24B] rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B] transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
                aria-label="Open mobile navigation menu"
                aria-expanded={mobileMenuOpen}
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-Over Drawer */}
      <div
        className={`fixed inset-0 z-50 lg:hidden transition-opacity duration-300 ${
          mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Backdrop */}
        <div
          className="fixed inset-0 bg-black/75 backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />

        {/* Drawer Panel */}
        <div
          className={`fixed top-0 right-0 bottom-0 w-full max-w-xs sm:max-w-sm bg-[#1A1009] border-l border-[#C9A24B]/20 shadow-2xl p-6 flex flex-col justify-between transition-transform duration-300 ease-out transform ${
            mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div>
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-6 border-b border-[#3A2417]">
              <div>
                <span className="font-serif text-2xl font-bold tracking-wider text-[#F5EBDD]">
                  Shaghf
                </span>
                <span className="text-[#C9A24B] text-base font-serif ml-2">شغف</span>
                <p className="text-[10px] uppercase tracking-[0.2em] text-[#C9A24B]">
                  Hanna Mall 2 · DHA Quetta
                </p>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-[#F5EBDD]/70 hover:text-[#F5EBDD] rounded-lg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
                aria-label="Close navigation menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Mobile Nav Links */}
            <nav className="mt-6 flex flex-col space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-4 py-3 text-base font-medium text-[#F5EBDD] hover:bg-[#2A180E] hover:text-[#C9A24B] rounded-lg transition-colors min-h-[44px] flex items-center"
                >
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          {/* Drawer Footer Actions */}
          <div className="pt-6 border-t border-[#3A2417] space-y-3">
            <a
              href={getWhatsAppOrderUrl()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold text-[#1E130C] bg-[#C9A24B] hover:bg-[#d9b259] rounded-xl transition-all shadow-md min-h-[44px]"
            >
              <MessageSquare className="w-4 h-4 fill-[#1E130C]" />
              <span>Order on WhatsApp</span>
            </a>

            <a
              href={`tel:${BUSINESS_INFO.rawPhone}`}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-medium text-[#F5EBDD] bg-[#25150D] hover:bg-[#321c11] border border-[#C9A24B]/30 rounded-xl transition-all min-h-[44px]"
            >
              <Phone className="w-4 h-4 text-[#C9A24B]" />
              <span>Call: {BUSINESS_INFO.phone}</span>
            </a>

            <div className="flex items-center gap-2 text-xs text-[#F5EBDD]/60 pt-2 px-1">
              <MapPin className="w-3.5 h-3.5 text-[#C9A24B] shrink-0" />
              <span className="truncate">3rd Floor, Hanna Mall 2, DHA Quetta</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
