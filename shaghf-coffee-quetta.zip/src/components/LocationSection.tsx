import React from 'react';
import { MapPin, Phone, Clock, Navigation, CheckCircle2, MessageSquare } from 'lucide-react';
import { BUSINESS_INFO, getWhatsAppOrderUrl } from '../data/coffeeData';

export const LocationSection: React.FC = () => {
  return (
    <section id="location" className="py-24 sm:py-32 bg-[#170E08] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-[0.3em] text-[#C9A24B] font-semibold">
            Visit Our Sanctuary
          </span>
          <h2 className="mt-2 text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-[#F5EBDD] tracking-tight">
            Location & Timings
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#F5EBDD]/70 font-light">
            Conveniently situated in DHA Quetta on the 3rd floor of Hanna Mall 2 with dedicated elevator access and serene panoramic views.
          </p>
        </div>

        {/* 2-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Details & Contact (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-[#1E130C] rounded-3xl p-8 sm:p-10 border border-[#3A2417] shadow-xl">
            <div className="space-y-8">
              {/* Address Block */}
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#28170D] border border-[#C9A24B]/30 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-[#C9A24B]" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#F5EBDD]">
                    Our Address
                  </h3>
                  <p className="text-sm text-[#F5EBDD]/80 mt-1 leading-relaxed">
                    {BUSINESS_INFO.address}
                  </p>
                  <span className="inline-block mt-2 text-xs text-[#C9A24B] font-medium">
                    Balochistan, Pakistan
                  </span>
                </div>
              </div>

              {/* Phone Block */}
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#28170D] border border-[#C9A24B]/30 flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-[#C9A24B]" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#F5EBDD]">
                    Phone & Reservations
                  </h3>
                  <a
                    href={`tel:${BUSINESS_INFO.rawPhone}`}
                    className="inline-block text-lg font-mono font-bold text-[#C9A24B] hover:text-[#d9b259] mt-1 tabular-nums transition-colors"
                  >
                    {BUSINESS_INFO.phone}
                  </a>
                  <p className="text-xs text-[#F5EBDD]/60 mt-0.5">
                    Tap to call directly or message via WhatsApp
                  </p>
                </div>
              </div>

              {/* Opening Hours Block */}
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#28170D] border border-[#C9A24B]/30 flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-[#C9A24B]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif text-lg font-bold text-[#F5EBDD]">
                      Opening Hours
                    </h3>
                    <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#1E130C] border border-[#C9A24B]/50 text-[10px] text-[#C9A24B] font-semibold">
                      <CheckCircle2 className="w-3 h-3 text-[#C9A24B]" />
                      <span>Open Daily</span>
                    </div>
                  </div>
                  <p className="text-sm font-medium text-[#F5EBDD]/90 mt-1">
                    {BUSINESS_INFO.hours}
                  </p>
                  <p className="text-xs text-[#F5EBDD]/60 mt-0.5">
                    Monday through Sunday, including public holidays
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-10 pt-6 border-t border-[#341F12] flex flex-col sm:flex-row gap-3.5">
              <a
                href={BUSINESS_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#1E130C] bg-[#C9A24B] hover:bg-[#d9b259] rounded-xl transition-all shadow-md active:scale-98 min-h-[44px]"
              >
                <Navigation className="w-4 h-4 text-[#1E130C]" />
                <span>Get Directions</span>
              </a>

              <a
                href={`tel:${BUSINESS_INFO.rawPhone}`}
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-medium text-[#F5EBDD] bg-[#28170D] hover:bg-[#341F12] border border-[#C9A24B]/40 rounded-xl transition-all active:scale-98 min-h-[44px]"
              >
                <Phone className="w-4 h-4 text-[#C9A24B]" />
                <span>Call Now</span>
              </a>
            </div>
          </div>

          {/* Right Column: Embedded Google Map (7 cols) */}
          <div className="lg:col-span-7 rounded-3xl overflow-hidden border border-[#3A2417] shadow-2xl relative min-h-[420px] lg:min-h-full bg-[#1A1009] flex flex-col">
            {/* Top Bar for Map */}
            <div className="p-4 bg-[#1E130C] border-b border-[#3A2417] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#C9A24B]" />
                <span className="text-xs font-semibold uppercase tracking-wider text-[#F5EBDD]">
                  Hanna Mall 2 · DHA Quetta
                </span>
              </div>
              <a
                href={BUSINESS_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-[#C9A24B] hover:underline flex items-center gap-1 font-medium"
              >
                <span>View Full Map</span>
                <Navigation className="w-3 h-3" />
              </a>
            </div>

            {/* Embedded Iframe */}
            <iframe
              title="Google Map location of Hanna Mall 2, DHA Quetta"
              src={BUSINESS_INFO.embedMapUrl}
              className="w-full h-full min-h-[380px] flex-grow border-0 grayscale-[40%] contrast-[110%] invert-[90%] hue-rotate-[180deg]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
