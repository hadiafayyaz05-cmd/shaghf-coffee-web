import React, { useState, useEffect, useRef } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { REVIEWS } from '../data/coffeeData';

export const ReviewsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % REVIEWS.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + REVIEWS.length) % REVIEWS.length);
  };

  // Auto-slide carousel every 4.5 seconds unless paused
  useEffect(() => {
    if (isPaused) return;

    timerRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % REVIEWS.length);
    }, 4500);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPaused]);

  return (
    <section id="reviews" className="py-24 sm:py-32 bg-[#1E130C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-[#C9A24B] font-semibold">
            Guest Testimonials
          </span>
          <h2 className="mt-2 text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-[#F5EBDD] tracking-tight">
            Loved Across Quetta
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#F5EBDD]/70 font-light">
            Read what our patrons say about the ambiance, artisanal coffee, and welcoming moments.
          </p>
        </div>

        {/* Carousel Container */}
        <div
          className="relative max-w-4xl mx-auto"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {/* Card Wrapper */}
          <div className="overflow-hidden rounded-3xl bg-[#170E08] border border-[#3A2417] shadow-2xl p-8 sm:p-12 relative min-h-[300px] flex flex-col justify-between">
            {/* Background Quote Watermark */}
            <Quote className="absolute top-6 right-8 w-24 h-24 text-[#C9A24B]/10 pointer-events-none" />

            <div className="relative z-10">
              {/* Star Rating */}
              <div className="flex items-center gap-1.5 mb-6">
                {[...Array(REVIEWS[currentIndex].rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-[#C9A24B] fill-[#C9A24B]"
                  />
                ))}
                <span className="ml-2 text-xs uppercase tracking-wider text-[#C9A24B] font-bold">
                  5.0 Verified Review
                </span>
              </div>

              {/* Review Text */}
              <blockquote className="font-serif text-lg sm:text-2xl text-[#F5EBDD] leading-relaxed italic transition-all duration-300">
                "{REVIEWS[currentIndex].review}"
              </blockquote>
            </div>

            {/* Reviewer Meta & Controls */}
            <div className="mt-8 pt-6 border-t border-[#2D1A10] flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
              <div>
                <h4 className="font-serif text-base sm:text-lg font-bold text-[#F5EBDD]">
                  {REVIEWS[currentIndex].name}
                </h4>
                <div className="flex items-center gap-2 text-xs text-[#F5EBDD]/60 mt-0.5">
                  <span>{REVIEWS[currentIndex].location}</span>
                  <span>·</span>
                  <span>{REVIEWS[currentIndex].date}</span>
                </div>
              </div>

              {/* Prev / Next Buttons */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={prevSlide}
                  className="w-10 h-10 rounded-full bg-[#25150D] hover:bg-[#C9A24B] text-[#F5EBDD] hover:text-[#1E130C] border border-[#C9A24B]/30 flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B] cursor-pointer"
                  aria-label="Previous review"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                {/* Dots indicator */}
                <div className="flex items-center gap-1.5 px-2">
                  {REVIEWS.map((_, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setCurrentIndex(i)}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        currentIndex === i
                          ? 'w-6 bg-[#C9A24B]'
                          : 'w-2 bg-[#422718] hover:bg-[#C9A24B]/50'
                      }`}
                      aria-label={`Go to slide ${i + 1}`}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={nextSlide}
                  className="w-10 h-10 rounded-full bg-[#25150D] hover:bg-[#C9A24B] text-[#F5EBDD] hover:text-[#1E130C] border border-[#C9A24B]/30 flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B] cursor-pointer"
                  aria-label="Next review"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
