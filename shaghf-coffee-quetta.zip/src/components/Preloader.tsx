import React, { useEffect, useState } from 'react';

interface PreloaderProps {
  onComplete?: () => void;
}

export const Preloader: React.FC<PreloaderProps> = ({ onComplete }) => {
  const [fading, setFading] = useState(false);
  const [removed, setRemoved] = useState(false);

  useEffect(() => {
    // Check if user prefers reduced motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const duration = prefersReducedMotion ? 200 : 900;

    const timer = setTimeout(() => {
      setFading(true);
      const removeTimer = setTimeout(() => {
        setRemoved(true);
        if (onComplete) onComplete();
      }, 500);
      return () => clearTimeout(removeTimer);
    }, duration);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (removed) return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#1E130C] text-[#F5EBDD] transition-opacity duration-500 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <div className="flex flex-col items-center text-center px-6">
        {/* Arabic Calligraphy Motif */}
        <span className="text-[#C9A24B] text-3xl font-serif tracking-widest mb-1 select-none animate-pulse">
          شغف
        </span>

        {/* Wordmark */}
        <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-[0.25em] text-[#F5EBDD] uppercase">
          SHAGHF
        </h1>

        <span className="text-xs uppercase tracking-[0.4em] text-[#C9A24B] mt-2 font-medium">
          Coffee Quetta · DHA
        </span>

        {/* Subtle gold line loader */}
        <div className="w-24 h-[2px] bg-[#3A2417] mt-6 overflow-hidden rounded-full relative">
          <div className="w-full h-full bg-[#C9A24B] origin-left animate-[shimmer_1.2s_ease-in-out_infinite]" />
        </div>
      </div>
    </div>
  );
};
