import React, { useState, useEffect, useRef } from 'react';
import { Coffee, Award, Sparkles, Heart } from 'lucide-react';
import { BUSINESS_INFO } from '../data/coffeeData';

export const StorySection: React.FC = () => {
  const [inView, setInView] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  // Counter values state
  const [followers, setFollowers] = useState(0);
  const [posts, setPosts] = useState(0);

  // Parallax tilt effect on mouse move over image
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 12; // max tilt +/- 6 deg
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -12;
    setMousePos({ x, y });
  };

  const handleMouseLeave = () => {
    setMousePos({ x: 0, y: 0 });
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
        }
      },
      { threshold: 0.25 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Animated counters when section enters viewport
  useEffect(() => {
    if (!inView) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setFollowers(2700);
      setPosts(300);
      return;
    }

    const duration = 1600; // ms
    const steps = 60;
    const intervalTime = duration / steps;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      // easeOutExpo
      const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);

      setFollowers(Math.floor(ease * 2700));
      setPosts(Math.floor(ease * 300));

      if (step >= steps) {
        clearInterval(timer);
        setFollowers(2700);
        setPosts(300);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [inView]);

  return (
    <section
      id="story"
      ref={sectionRef}
      className="py-24 sm:py-32 bg-[#170E08] relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column: Image with Parallax / Tilt & Gold Accent Frame */}
          <div
            className="relative perspective-1000"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
          >
            {/* Background luxury gold wireframe offset */}
            <div className="absolute -inset-3 sm:-inset-4 rounded-3xl border border-[#C9A24B]/30 -rotate-2 pointer-events-none" />

            <div
              className="relative rounded-2xl overflow-hidden shadow-2xl bg-[#28170D] transition-transform duration-300 ease-out will-change-transform"
              style={{
                transform: `rotateY(${mousePos.x}deg) rotateX(${mousePos.y}deg)`,
              }}
            >
              <img
                src="/src/assets/images/story_cafe_interior_1791989705205.jpg"
                alt="Shaghf Coffee Barista and Luxury Lounge Interior at Hanna Mall 2, DHA Quetta"
                className="w-full h-[380px] sm:h-[460px] lg:h-[500px] object-cover object-center"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1E130C] via-transparent to-transparent opacity-60" />

              {/* Inset Badge */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-[#1E130C]/85 border border-[#C9A24B]/40 backdrop-blur-md">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#C9A24B]/20 border border-[#C9A24B] flex items-center justify-center shrink-0">
                    <Coffee className="w-5 h-5 text-[#C9A24B]" />
                  </div>
                  <div>
                    <h4 className="font-serif text-sm font-bold text-[#F5EBDD]">
                      Artisanal Arabica Roasts
                    </h4>
                    <p className="text-xs text-[#F5EBDD]/70">
                      Crafted freshly daily on 3rd Floor, Hanna Mall 2
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative & Counter Stats */}
          <div className="flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-[#C9A24B]" />
              <span className="text-xs uppercase tracking-[0.25em] text-[#C9A24B] font-semibold">
                Our Story & Philosophy
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-[#F5EBDD] tracking-tight leading-tight">
              Where Passion Meets The Art of Coffee
            </h2>

            <div className="mt-6 space-y-4 text-base text-[#F5EBDD]/80 leading-relaxed font-light">
              <p>
                Founded on the belief that a cup of coffee is an intimate ritual,{' '}
                <strong className="text-[#F5EBDD] font-medium">Shaghf Coffee Quetta</strong> brings an international specialty coffee sanctuary to the heart of DHA Quetta.
              </p>
              <p>
                The word <em className="text-[#C9A24B] font-serif not-italic font-medium">"Shaghf" (شغف)</em> embodies intense passion and longing. From sourcing premium 100% Arabica beans to calibrating each espresso shot with mathematical precision, our master baristas celebrate hospitality in its purest, most luxurious form.
              </p>
              <p className="font-serif italic text-lg text-[#C9A24B]/90 pt-1">
                "{BUSINESS_INFO.tagline}"
              </p>
            </div>

            {/* 3 Animated Stats */}
            <div className="mt-10 grid grid-cols-3 gap-4 sm:gap-6 pt-8 border-t border-[#341F12]">
              {/* Stat 1: Followers */}
              <div className="flex flex-col">
                <div className="font-mono text-2xl sm:text-3xl lg:text-4xl font-bold text-[#C9A24B] tabular-nums">
                  {followers.toLocaleString()}+
                </div>
                <div className="text-xs sm:text-sm text-[#F5EBDD]/70 mt-1 font-medium">
                  Followers
                </div>
              </div>

              {/* Stat 2: Posts */}
              <div className="flex flex-col">
                <div className="font-mono text-2xl sm:text-3xl lg:text-4xl font-bold text-[#C9A24B] tabular-nums">
                  {posts.toLocaleString()}+
                </div>
                <div className="text-xs sm:text-sm text-[#F5EBDD]/70 mt-1 font-medium">
                  Posts
                </div>
              </div>

              {/* Stat 3: Daily Fresh Brew */}
              <div className="flex flex-col">
                <div className="font-serif text-xl sm:text-2xl lg:text-3xl font-bold text-[#C9A24B] flex items-center gap-1">
                  100%
                </div>
                <div className="text-xs sm:text-sm text-[#F5EBDD]/70 mt-1 font-medium">
                  Daily Fresh Brew
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
