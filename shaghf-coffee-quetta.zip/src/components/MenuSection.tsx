import React, { useState } from 'react';
import { Coffee, Utensils, CakeSlice, MessageSquare, Sparkles } from 'lucide-react';
import { MENU_ITEMS, MenuItem, getWhatsAppOrderUrl } from '../data/coffeeData';

export const MenuSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'coffee' | 'snacks' | 'desserts'>('coffee');

  const tabs = [
    { id: 'coffee' as const, label: 'Coffee', icon: Coffee, count: 4 },
    { id: 'snacks' as const, label: 'Snacks & Melts', icon: Utensils, count: 2 },
    { id: 'desserts' as const, label: 'Desserts & Sweets', icon: CakeSlice, count: 2 },
  ];

  const filteredItems = MENU_ITEMS.filter((item) => item.category === activeTab);

  return (
    <section id="menu" className="py-24 sm:py-32 bg-[#170E08] relative overflow-hidden">
      {/* Decorative subtle ambient lights */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#C9A24B]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#C9A24B]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section 3: Menu Intro */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="h-[1px] w-8 bg-[#C9A24B]/60" />
            <span className="text-xs uppercase tracking-[0.3em] text-[#C9A24B] font-semibold">
              Handcrafted Indulgence
            </span>
            <span className="h-[1px] w-8 bg-[#C9A24B]/60" />
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-[#F5EBDD] tracking-tight">
            Our Menu
          </h2>

          <p className="mt-4 text-base sm:text-lg text-[#F5EBDD]/80 leading-relaxed font-light">
            Freshly brewed coffee, cozy snacks aur desserts, sab kuch ek jagah.
          </p>
        </div>

        {/* Section 4: 3 Filter Tabs */}
        <div className="flex justify-center mb-12">
          <div
            role="tablist"
            aria-label="Menu categories"
            className="inline-flex p-1.5 rounded-2xl bg-[#23150D] border border-[#C9A24B]/20 shadow-inner max-w-full overflow-x-auto"
          >
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={isActive}
                  aria-controls={`panel-${tab.id}`}
                  id={`tab-${tab.id}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-5 sm:px-6 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold rounded-xl transition-all duration-300 whitespace-nowrap min-h-[44px] cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B] ${
                    isActive
                      ? 'bg-[#C9A24B] text-[#1E130C] shadow-lg shadow-[#C9A24B]/20'
                      : 'text-[#F5EBDD]/70 hover:text-[#F5EBDD] hover:bg-[#2F1D12]'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Items Cards Grid with Stagger Animation */}
        <div
          id={`panel-${activeTab}`}
          role="tabpanel"
          aria-labelledby={`tab-${activeTab}`}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className="group flex flex-col bg-[#1E130C] rounded-2xl overflow-hidden border border-[#3A2417] hover:border-[#C9A24B]/50 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-black/60"
              style={{
                animation: `fadeInUp 0.5s ease-out forwards ${index * 80}ms`,
              }}
            >
              {/* Card Image with Hover Zoom & Fallback */}
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#28170D]">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-105"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    // Resilient styled fallback container
                    e.currentTarget.style.display = 'none';
                    const parent = e.currentTarget.parentElement;
                    if (parent) {
                      const fallback = document.createElement('div');
                      fallback.className = 'w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#28170D] to-[#1A0E08]';
                      fallback.innerHTML = `<span class="text-3xl font-serif text-[#C9A24B] mb-2">☕</span><span class="text-xs uppercase tracking-wider text-[#F5EBDD]/70 font-medium">${item.name}</span>`;
                      parent.appendChild(fallback);
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1E130C] via-transparent to-transparent opacity-80" />

                {item.popular && (
                  <div className="absolute top-3.5 right-3.5 flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1E130C]/85 border border-[#C9A24B]/50 backdrop-blur-md">
                    <Sparkles className="w-3 h-3 text-[#C9A24B]" />
                    <span className="text-[11px] font-semibold text-[#C9A24B] uppercase tracking-wider">
                      Signature
                    </span>
                  </div>
                )}
              </div>

              {/* Card Details */}
              <div className="p-6 flex flex-col flex-grow justify-between">
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h3 className="font-serif text-xl font-bold text-[#F5EBDD] group-hover:text-[#C9A24B] transition-colors">
                      {item.name}
                    </h3>
                    <div className="shrink-0 font-mono text-lg font-bold text-[#C9A24B] tabular-nums whitespace-nowrap">
                      Rs. {item.price.toLocaleString()}
                    </div>
                  </div>

                  <p className="text-sm text-[#F5EBDD]/70 leading-relaxed font-light line-clamp-2">
                    {item.description}
                  </p>
                </div>

                {/* Card Action */}
                <div className="mt-6 pt-4 border-t border-[#341F12] flex items-center justify-between">
                  <span className="text-xs text-[#C9A24B]/80 font-medium">
                    Freshly Prepared
                  </span>

                  <a
                    href={getWhatsAppOrderUrl(item.name, item.price)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#1E130C] bg-[#C9A24B] hover:bg-[#d9b259] rounded-lg transition-colors shadow-sm active:scale-95"
                    aria-label={`Order ${item.name} on WhatsApp`}
                  >
                    <MessageSquare className="w-3.5 h-3.5 fill-[#1E130C]" />
                    <span>Order</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
