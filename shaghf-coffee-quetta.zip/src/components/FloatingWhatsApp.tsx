import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import { getWhatsAppOrderUrl, BUSINESS_INFO } from '../data/coffeeData';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
      {/* Tooltip badge that user can dismiss */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#1E130C]/95 border border-[#C9A24B]/40 text-[#F5EBDD] text-xs shadow-xl backdrop-blur-md animate-fadeIn">
          <span className="w-2 h-2 rounded-full bg-[#25D366] shrink-0" />
          <span className="font-medium text-[#F5EBDD]">Chat & Order on WhatsApp</span>
          <button
            type="button"
            onClick={() => setShowTooltip(false)}
            className="text-[#F5EBDD]/60 hover:text-[#F5EBDD] ml-1 p-0.5 rounded-full"
            aria-label="Close tooltip"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={getWhatsAppOrderUrl()}
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white flex items-center justify-center shadow-2xl transition-all duration-300 hover:scale-108 active:scale-95 animate-pulse-gold focus:outline-none focus-visible:ring-4 focus-visible:ring-[#25D366]/40"
        aria-label="Order or message Shaghf Coffee Quetta on WhatsApp"
      >
        <MessageSquare className="w-7 h-7 fill-white text-white" />
      </a>
    </div>
  );
};
