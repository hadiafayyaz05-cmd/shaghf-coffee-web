import React from 'react';
import { Gift, ArrowRight } from 'lucide-react';
import { getWhatsAppOfferUrl } from '../data/coffeeData';

export const OfferBanner: React.FC = () => {
  return (
    <section id="offer" className="relative overflow-hidden bg-gradient-to-r from-[#B58B35] via-[#DDB85D] to-[#B58B35] text-[#1E130C] py-7 sm:py-8 shadow-xl">
      {/* Subtle Shimmer Animation Overlay */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="w-1/2 h-full bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12 animate-shimmer" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-5 sm:gap-6 text-center md:text-left">
          {/* Offer Title & Copy */}
          <div className="flex flex-col sm:flex-row items-center gap-3.5 sm:gap-5">
            <div className="w-12 h-12 rounded-full bg-[#1E130C]/10 border border-[#1E130C]/20 flex items-center justify-center shrink-0">
              <Gift className="w-6 h-6 text-[#1E130C]" />
            </div>

            <div>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 sm:gap-3">
                <span className="font-serif text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight text-[#1E130C]">
                  Double the Coffee, Double the Joy!
                </span>
                <span className="font-mono text-xl sm:text-2xl md:text-3xl font-black bg-[#1E130C] text-[#F5EBDD] px-3.5 py-0.5 rounded-lg tabular-nums shadow-sm">
                  Rs. 2,500
                </span>
              </div>
              <p className="text-xs sm:text-sm font-medium text-[#1E130C]/85 mt-1">
                Pair any 2 specialty brews with your choice of 2 artisan snacks or desserts.
              </p>
            </div>
          </div>

          {/* Action Button */}
          <div className="shrink-0 w-full sm:w-auto">
            <a
              href={getWhatsAppOfferUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3 text-sm font-bold uppercase tracking-wider text-[#F5EBDD] bg-[#1E130C] hover:bg-[#2F1D12] rounded-full transition-all duration-200 shadow-lg hover:shadow-xl active:scale-95 min-h-[46px]"
            >
              <span>Order Now</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
