import React, { useState, useEffect, useCallback } from 'react';
import { Eye, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/coffeeData';

export const GallerySection: React.FC = () => {
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setSelectedPhotoIndex(index);
  };

  const closeLightbox = () => {
    setSelectedPhotoIndex(null);
  };

  const showNext = useCallback(() => {
    if (selectedPhotoIndex === null) return;
    setSelectedPhotoIndex((prev) => (prev! + 1) % GALLERY_ITEMS.length);
  }, [selectedPhotoIndex]);

  const showPrev = useCallback(() => {
    if (selectedPhotoIndex === null) return;
    setSelectedPhotoIndex((prev) => (prev! - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length);
  }, [selectedPhotoIndex]);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedPhotoIndex === null) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') showNext();
      if (e.key === 'ArrowLeft') showPrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedPhotoIndex, showNext, showPrev]);

  // Lock body scroll when lightbox is open
  useEffect(() => {
    if (selectedPhotoIndex !== null) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedPhotoIndex]);

  return (
    <section id="gallery" className="py-24 sm:py-32 bg-[#1E130C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-[0.3em] text-[#C9A24B] font-semibold">
            Visual Ambiance
          </span>
          <h2 className="mt-2 text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-[#F5EBDD] tracking-tight">
            The Shaghf Experience
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#F5EBDD]/70 font-light">
            A glimpse into the warmth, craftsmanship, and indulgent moments on the 3rd Floor of Hanna Mall 2.
          </p>
        </div>

        {/* Masonry / Responsive Grid of 6 Photos */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
          {GALLERY_ITEMS.map((item, index) => (
            <div
              key={item.id}
              onClick={() => openLightbox(index)}
              className="group relative cursor-pointer overflow-hidden rounded-2xl bg-[#28170D] border border-[#3A2417] hover:border-[#C9A24B]/50 transition-all duration-300 shadow-md hover:shadow-2xl aspect-[4/3]"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-108"
                loading="lazy"
                referrerPolicy="no-referrer"
              />

              {/* Dark Hover Overlay with View Icon */}
              <div className="absolute inset-0 bg-[#1E130C]/75 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-6 text-center backdrop-blur-[2px]">
                <div className="w-12 h-12 rounded-full bg-[#C9A24B] text-[#1E130C] flex items-center justify-center shadow-lg transform -translate-y-2 group-hover:translate-y-0 transition-transform duration-300 mb-3">
                  <Eye className="w-5 h-5" />
                </div>
                <span className="text-xs uppercase tracking-[0.2em] text-[#C9A24B] font-medium">
                  {item.category}
                </span>
                <h4 className="font-serif text-lg font-bold text-[#F5EBDD] mt-1">
                  {item.title}
                </h4>
                <span className="mt-2 text-[11px] text-[#F5EBDD]/60 flex items-center gap-1">
                  Click to Expand
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedPhotoIndex !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Photo Lightbox"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4 sm:p-8 backdrop-blur-md transition-opacity duration-300 animate-fadeIn"
          onClick={closeLightbox}
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={closeLightbox}
            className="absolute top-5 right-5 z-20 p-2.5 rounded-full bg-[#1E130C]/80 hover:bg-[#C9A24B] text-[#F5EBDD] hover:text-[#1E130C] border border-[#C9A24B]/30 transition-all duration-200 min-w-[44px] min-h-[44px] flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B]"
            aria-label="Close Lightbox"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Left Arrow */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              showPrev();
            }}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-[#1E130C]/80 hover:bg-[#C9A24B] text-[#F5EBDD] hover:text-[#1E130C] border border-[#C9A24B]/30 transition-all duration-200 min-w-[48px] min-h-[48px] flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B]"
            aria-label="Previous photo"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Right Arrow */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              showNext();
            }}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-[#1E130C]/80 hover:bg-[#C9A24B] text-[#F5EBDD] hover:text-[#1E130C] border border-[#C9A24B]/30 transition-all duration-200 min-w-[48px] min-h-[48px] flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A24B]"
            aria-label="Next photo"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Content Container */}
          <div
            className="relative max-w-5xl max-h-[85vh] flex flex-col items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={GALLERY_ITEMS[selectedPhotoIndex].image}
              alt={GALLERY_ITEMS[selectedPhotoIndex].title}
              className="max-h-[70vh] sm:max-h-[75vh] w-auto max-w-full object-contain rounded-xl shadow-2xl border border-[#C9A24B]/20"
            />

            {/* Lightbox Caption & Counter */}
            <div className="mt-4 flex flex-col sm:flex-row items-center justify-between w-full px-2 text-center sm:text-left gap-2">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#C9A24B]">
                  {GALLERY_ITEMS[selectedPhotoIndex].category}
                </span>
                <h3 className="font-serif text-lg sm:text-xl font-bold text-[#F5EBDD]">
                  {GALLERY_ITEMS[selectedPhotoIndex].title}
                </h3>
              </div>
              <div className="font-mono text-sm text-[#F5EBDD]/60 tabular-nums">
                {selectedPhotoIndex + 1} / {GALLERY_ITEMS.length}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
