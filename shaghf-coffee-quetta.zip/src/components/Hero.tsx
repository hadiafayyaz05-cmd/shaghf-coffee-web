import React, { useState, useEffect } from 'react';
import { ChevronDown, MessageSquare, Navigation, Sparkles } from 'lucide-react';
import { BUSINESS_INFO, getWhatsAppOrderUrl } from '../data/coffeeData';

export const Hero: React.FC = () => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const heroWords = "Quetta mein coffee ka asli ahsaas".split(" ");

  useEffect(() => {
    // Fallback if image load event doesn't fire
    const timer = setTimeout(() => setImageLoaded(true), 150);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section
      id="home"
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#1E130C]"
    >
      {/* Background Image Container with Ken Burns Zoom & Scrim */}
      <div className="absolute inset-0 w-full h-full overflow-hidden select-none pointer-events-none">
        <img
          src="/src/assets/images/hero_coffee_latte_1791989704165.jpg"
          alt="Artisanal espresso and latte art at Shaghf Coffee Quetta"
          className="w-full h-full object-cover object-center animate-ken-burns scale-105 transform will-change-transform"
          loading="eager"
          referrerPolicy="no-referrer"
          onLoad={() => setImageLoaded(true)}
        />
        {/* Dark espresso gradient scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1E130C] via-[#1E130C]/75 to-[#1E130C]/40" />
        <div className="absolute inset-0 bg-radial-[circle_at_center,_transparent_0%,_#1E130C_90%] opacity-70" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-24 pb-16 flex flex-col items-center">
        {/* Arabic Calligraphy & Sub-brand Header */}
        <div className="inline-flex items-center gap-2 mb-4 px-4 py-1.5 rounded-full bg-[#1E130C]/60 border border-[#C9A24B]/30 backdrop-blur-sm shadow-md">
          <Sparkles className="w-3.5 h-3.5 text-[#C9A24B]" />
          <span className="text-xs md:text-sm font-medium tracking-widest uppercase text-[#C9A24B]">
            Hanna Mall 2 · DHA Quetta
          </span>
          <span className="text-xs text-[#C9A24B]/80 font-serif">شغف</span>
        </div>

        {/* Urdu Heading: Fades in word by word */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-[#F5EBDD] tracking-tight leading-[1.15] max-w-4xl text-balance">
          {heroWords.map((word, index) => (
            <span
              key={index}
              className="inline-block mr-2 sm:mr-3.5 transition-all duration-700 ease-out"
              style={{
                opacity: imageLoaded ? 1 : 0,
                transform: imageLoaded ? 'translateY(0)' : 'translateY(16px)',
                transitionDelay: `${index * 120 + 200}ms`
              }}
            >
              {word === "asli" || word === "ahsaas" ? (
                <span className="text-[#C9A24B] italic">{word}</span>
              ) : (
                word
              )}
            </span>
          ))}
        </h1>

        {/* Subheading: Slides up after */}
        <p
          className="mt-6 text-base sm:text-lg md:text-xl text-[#F5EBDD]/90 max-w-2xl font-light leading-relaxed transition-all duration-700 ease-out"
          style={{
            opacity: imageLoaded ? 1 : 0,
            transform: imageLoaded ? 'translateY(0)' : 'translateY(20px)',
            transitionDelay: '700ms'
          }}
        >
          {BUSINESS_INFO.urduSubtitle}
        </p>

        {/* Brand Tagline */}
        <p
          className="mt-3 text-xs sm:text-sm font-serif italic tracking-wide text-[#C9A24B] transition-all duration-700 ease-out"
          style={{
            opacity: imageLoaded ? 1 : 0,
            transform: imageLoaded ? 'translateY(0)' : 'translateY(20px)',
            transitionDelay: '850ms'
          }}
        >
          "{BUSINESS_INFO.tagline}"
        </p>

        {/* Two Call to Action Buttons */}
        <div
          className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto transition-all duration-700 ease-out"
          style={{
            opacity: imageLoaded ? 1 : 0,
            transform: imageLoaded ? 'translateY(0)' : 'translateY(24px)',
            transitionDelay: '1000ms'
          }}
        >
          {/* Primary: Order on WhatsApp */}
          <a
            href={getWhatsAppOrderUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-sm sm:text-base font-semibold text-[#1E130C] bg-[#C9A24B] hover:bg-[#d9b259] rounded-full transition-all duration-200 shadow-xl shadow-[#C9A24B]/20 hover:shadow-2xl hover:shadow-[#C9A24B]/30 active:scale-98 min-h-[48px]"
          >
            <MessageSquare className="w-5 h-5 fill-[#1E130C]" />
            <span>Order on WhatsApp</span>
          </a>

          {/* Outline: Get Directions */}
          <a
            href="#location"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-sm sm:text-base font-medium text-[#F5EBDD] bg-black/20 hover:bg-[#1E130C]/60 border border-[#C9A24B]/70 hover:border-[#C9A24B] rounded-full transition-all duration-200 backdrop-blur-sm active:scale-98 min-h-[48px]"
          >
            <Navigation className="w-4 h-4 text-[#C9A24B]" />
            <span>Get Directions</span>
          </a>
        </div>
      </div>

      {/* Animated Scroll Down Arrow */}
      <a
        href="#menu"
        aria-label="Scroll down to menu section"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center text-[#F5EBDD]/60 hover:text-[#C9A24B] transition-colors group cursor-pointer"
      >
        <span className="text-[11px] uppercase tracking-[0.25em] mb-1 font-medium group-hover:tracking-[0.3em] transition-all">
          Explore Menu
        </span>
        <div className="w-8 h-8 rounded-full border border-[#C9A24B]/30 flex items-center justify-center animate-bounce">
          <ChevronDown className="w-4 h-4 text-[#C9A24B]" />
        </div>
      </a>
    </section>
  );
};
