import React, { useEffect, useRef, useState } from 'react';
import { Instagram, Facebook, Phone, MessageSquare, MapPin } from 'lucide-react';
import { BUSINESS_INFO, getWhatsAppOrderUrl } from '../data/coffeeData';

export const Footer: React.FC = () => {
  const [lineVisible, setLineVisible] = useState(false);
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setLineVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (footerRef.current) {
      observer.observe(footerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <footer
      id="contact"
      ref={footerRef}
      className="bg-[#140C07] text-[#F5EBDD] relative overflow-hidden"
    >
      {/* Subtle gold line that animates across the top on scroll into view */}
      <div className="w-full h-[2px] bg-[#2E1A0F] overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r from-transparent via-[#C9A24B] to-transparent transition-all duration-1000 ease-out ${
            lineVisible ? 'w-full opacity-100 scale-x-100' : 'w-0 opacity-0 scale-x-0'
          }`}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-14 border-b border-[#2A180E]">
          {/* Brand Info & Tagline (5 cols) */}
          <div className="lg:col-span-5">
            <div className="flex items-center gap-2.5 mb-3">
              <span className="font-serif text-3xl font-bold tracking-wider text-[#F5EBDD]">
                Shaghf
              </span>
              <span className="text-[#C9A24B] text-2xl font-serif">شغف</span>
              <span className="text-xs uppercase tracking-widest text-[#C9A24B] font-semibold border-l border-[#C9A24B]/40 pl-2.5">
                Quetta
              </span>
            </div>

            <p className="font-serif italic text-[#C9A24B] text-base leading-relaxed mt-3 max-w-md">
              "{BUSINESS_INFO.tagline}"
            </p>

            <p className="text-xs sm:text-sm text-[#F5EBDD]/60 mt-3 leading-relaxed max-w-md font-light">
              Elevating specialty coffee culture in DHA Quetta. Hanna Mall 2, 3rd Floor. Artisanal espresso, single-origin pour-overs, and handcrafted desserts.
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-3.5 mt-6">
              <a
                href={BUSINESS_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1E130C] border border-[#3A2417] hover:border-[#C9A24B] text-[#F5EBDD] hover:text-[#C9A24B] flex items-center justify-center transition-all duration-200"
                aria-label="Follow Shaghf Coffee Quetta on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href={BUSINESS_INFO.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1E130C] border border-[#3A2417] hover:border-[#C9A24B] text-[#F5EBDD] hover:text-[#C9A24B] flex items-center justify-center transition-all duration-200"
                aria-label="Follow Shaghf Coffee Quetta on Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>

              <a
                href={getWhatsAppOrderUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#1E130C] border border-[#3A2417] hover:border-[#C9A24B] text-[#F5EBDD] hover:text-[#C9A24B] flex items-center justify-center transition-all duration-200"
                aria-label="Chat with Shaghf Coffee on WhatsApp"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="text-xs uppercase tracking-[0.2em] font-semibold text-[#C9A24B] mb-4">
              Quick Navigation
            </h4>
            <ul className="space-y-2.5 text-sm text-[#F5EBDD]/80">
              <li>
                <a href="#home" className="hover:text-[#C9A24B] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#menu" className="hover:text-[#C9A24B] transition-colors">
                  Our Menu
                </a>
              </li>
              <li>
                <a href="#offer" className="hover:text-[#C9A24B] transition-colors">
                  Double Delight Offer
                </a>
              </li>
              <li>
                <a href="#story" className="hover:text-[#C9A24B] transition-colors">
                  Our Story
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#C9A24B] transition-colors">
                  Gallery
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-[#C9A24B] transition-colors">
                  Location & Hours
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details (4 cols) */}
          <div className="lg:col-span-4">
            <h4 className="text-xs uppercase tracking-[0.2em] font-semibold text-[#C9A24B] mb-4">
              Contact & Social
            </h4>
            <div className="space-y-3 text-sm text-[#F5EBDD]/80">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C9A24B] shrink-0 mt-0.5" />
                <span>{BUSINESS_INFO.address}</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#C9A24B] shrink-0" />
                <a
                  href={`tel:${BUSINESS_INFO.rawPhone}`}
                  className="font-mono text-[#C9A24B] hover:underline"
                >
                  {BUSINESS_INFO.phone}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Instagram className="w-4 h-4 text-[#C9A24B] shrink-0" />
                <a
                  href={BUSINESS_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#C9A24B] transition-colors"
                >
                  {BUSINESS_INFO.instagram}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Facebook className="w-4 h-4 text-[#C9A24B] shrink-0" />
                <a
                  href={BUSINESS_INFO.facebookUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#C9A24B] transition-colors"
                >
                  {BUSINESS_INFO.facebook}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright & Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#F5EBDD]/60 text-center sm:text-left">
          <p>© 2026 Shaghf Coffee Quetta. All rights reserved.</p>
          <p className="flex items-center gap-1.5">
            <span>Specialty Coffee Lounge · Hanna Mall 2, DHA Quetta</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
