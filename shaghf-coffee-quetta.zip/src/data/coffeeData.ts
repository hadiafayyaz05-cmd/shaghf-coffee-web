export interface MenuItem {
  id: string;
  name: string;
  category: 'coffee' | 'snacks' | 'desserts';
  description: string;
  price: number;
  image: string;
  popular?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  aspect: string;
}

export interface ReviewItem {
  id: string;
  name: string;
  location: string;
  rating: number;
  review: string;
  date: string;
}

export const BUSINESS_INFO = {
  name: "Shaghf Coffee Quetta",
  tagline: "We are not just brewing coffee; we are creating an indulgent lifestyle.",
  urduTagline: "Quetta mein coffee ka asli ahsaas",
  urduSubtitle: "Hanna Mall 2, DHA Quetta ki ek khoobsurat jagah jahan har cup ek experience hai.",
  phone: "0370 5234235",
  rawPhone: "+923705234235",
  address: "3rd Floor, Hanna Mall 2, DHA Quetta, Pakistan",
  hours: "10:00 AM – 12:00 AM Daily",
  instagram: "@shaghfquetta.pk",
  instagramUrl: "https://instagram.com/shaghfquetta.pk",
  facebook: "Shaghf Coffee Quetta",
  facebookUrl: "https://facebook.com/shaghfquetta",
  googleMapsUrl: "https://maps.google.com/?q=Hanna+Mall+2+DHA+Quetta+Pakistan",
  embedMapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d110196.16616453664!2d66.97445778847656!3d30.228518900000005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ed2df54f15a6b57%3A0x6bcfad4bf1ad7a54!2sDHA%20Quetta!5e0!3m2!1sen!2s!4v1710000000000!5m2!1sen!2s",
  stats: [
    { value: 2700, label: "Followers", suffix: "+" },
    { value: 300, label: "Posts", suffix: "+" },
    { value: 100, label: "Daily Fresh Brew", suffix: "% Arabica", isText: true, textVal: "Daily Fresh Brew" }
  ]
};

export const MENU_ITEMS: MenuItem[] = [
  // Coffee
  {
    id: "cappuccino",
    name: "Classic Cappuccino",
    category: "coffee",
    description: "Rich double shot espresso enveloped in velvety micro-foam with subtle cocoa dust.",
    price: 650,
    image: "/src/assets/images/hero_coffee_latte_1791989704165.jpg",
    popular: true
  },
  {
    id: "caramel-latte",
    name: "Caramel Macchiato Latte",
    category: "coffee",
    description: "Layered steamed whole milk, robust espresso, and artisanal butter caramel drizzle.",
    price: 750,
    image: "/src/assets/images/coffee_caramel_latte_1791989705424.jpg",
    popular: true
  },
  {
    id: "cold-brew",
    name: "Nitro Cold Brew",
    category: "coffee",
    description: "Slow-steeped for 18 hours, infused with nitrogen for a silky, naturally sweet finish.",
    price: 700,
    image: "/src/assets/images/cold_brew_glass_1791989753557.jpg"
  },
  {
    id: "v60-pourover",
    name: "Artisanal V60 Pour Over",
    category: "coffee",
    description: "Single-origin Ethiopian beans precisely hand-brewed with distinct floral and citrus notes.",
    price: 780,
    image: "/src/assets/images/pourover_coffee_bar_1791989755609.jpg"
  },
  // Snacks
  {
    id: "club-sandwich",
    name: "Shaghf Signature Club Sandwich",
    category: "snacks",
    description: "Smoked chicken, crispy beef bacon, melted sharp cheddar, egg, and herb mayo with seasoned fries.",
    price: 950,
    image: "/src/assets/images/snack_club_sandwich_1791989705583.jpg",
    popular: true
  },
  {
    id: "croissant-panini",
    name: "Artisan Truffle & Mozzarella Melt",
    category: "snacks",
    description: "Toasted brioche panini layered with buffalo mozzarella, fresh basil pesto, and roma tomatoes.",
    price: 850,
    image: "/src/assets/images/snack_club_sandwich_1791989705583.jpg"
  },
  // Desserts
  {
    id: "brownie-gelato",
    name: "Fudge Brownie with Gelato",
    category: "desserts",
    description: "Warm Belgian dark chocolate brownie topped with Madagascar vanilla bean gelato and ganache.",
    price: 580,
    image: "/src/assets/images/artisanal_brownie_1791989754741.jpg",
    popular: true
  },
  {
    id: "cheesecake",
    name: "San Sebastián Basque Cheesecake",
    category: "desserts",
    description: "Caramelized crust with an ultra-creamy custard center, fresh raspberries, and edible gold leaf.",
    price: 720,
    image: "/src/assets/images/dessert_cheesecake_1791989705300.jpg",
    popular: true
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "g1",
    title: "Latte Art Craftsmanship",
    category: "Artisanal Pour",
    image: "/src/assets/images/hero_coffee_latte_1791989704165.jpg",
    aspect: "tall"
  },
  {
    id: "g2",
    title: "V60 Hand Brew Bar",
    category: "Specialty Brewing",
    image: "/src/assets/images/pourover_coffee_bar_1791989755609.jpg",
    aspect: "wide"
  },
  {
    id: "g3",
    title: "Luxury Lounge Ambience",
    category: "DHA Quetta Lounge",
    image: "/src/assets/images/story_cafe_interior_1791989705205.jpg",
    aspect: "wide"
  },
  {
    id: "g4",
    title: "Layered Caramel Macchiato",
    category: "Signature Beverage",
    image: "/src/assets/images/coffee_caramel_latte_1791989705424.jpg",
    aspect: "tall"
  },
  {
    id: "g5",
    title: "Gourmet Club Sandwich",
    category: "Artisanal Kitchen",
    image: "/src/assets/images/snack_club_sandwich_1791989705583.jpg",
    aspect: "wide"
  },
  {
    id: "g6",
    title: "Basque Cheesecake & Berries",
    category: "Patisserie",
    image: "/src/assets/images/dessert_cheesecake_1791989705300.jpg",
    aspect: "wide"
  }
];

export const REVIEWS: ReviewItem[] = [
  {
    id: "r1",
    name: "Hamza Khan Tareen",
    location: "DHA Quetta",
    rating: 5,
    review: "The Spanish Latte is unmatched anywhere in Quetta. The peaceful luxury atmosphere on the 3rd floor of Hanna Mall 2 makes it our favorite spot for relaxed evenings and business catchups.",
    date: "October 2026"
  },
  {
    id: "r2",
    name: "Dr. Fatima Kakar",
    location: "Quetta Cantonment",
    rating: 5,
    review: "Finally, a world-class specialty coffee sanctuary in DHA Quetta! The Basque cheesecake paired with their slow-steeped cold brew is absolute indulgence. The baristas truly know their craft.",
    date: "September 2026"
  },
  {
    id: "r3",
    name: "Bilal Ahmed",
    location: "Chiltan Housing",
    rating: 5,
    review: "Exquisite interior with warm brass and deep espresso woods. Their club sandwich was fresh, crisp, and flavorful. Shaghf has elevated the cafe culture of Quetta to international standards.",
    date: "September 2026"
  }
];

export function getWhatsAppOrderUrl(itemName?: string, price?: number) {
  let message = "Salam Shaghf Coffee Quetta! ";
  if (itemName && price) {
    message += `I would like to order the ${itemName} (Rs. ${price.toLocaleString()}). Please let me know the preparation time and takeaway/dine-in details.`;
  } else {
    message += "I'd like to check your menu and place an order at Hanna Mall 2, DHA Quetta.";
  }
  return `https://wa.me/923705234235?text=${encodeURIComponent(message)}`;
}

export function getWhatsAppOfferUrl() {
  const message = "Salam Shaghf Coffee Quetta! I would like to order the 'Double the Coffee, Double the Joy!' deal for Rs. 2,500.";
  return `https://wa.me/923705234235?text=${encodeURIComponent(message)}`;
}
